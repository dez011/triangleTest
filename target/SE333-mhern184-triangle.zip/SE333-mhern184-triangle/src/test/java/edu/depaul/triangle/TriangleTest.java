package edu.depaul.triangle;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class TriangleTest {
	
	@Test
	@DisplayName("Should recognize Isosceles triangles")
	void testIsosceles() {
		fail("Not implemented yet");
	}

	@Test
	@DisplayName("Error example")
	void demoError() {
		throw new RuntimeException("Also not implemented yet");
	}
}
